library(sf)
ecoregions = read_sf("data/ecoregions.gpkg")
ecoregions
# What type of data does it store? Vector data of class sf
class(ecoregions)
# What is the coordinate system used? WGS 84 (EPSG 4326)
st_crs(ecoregions)
# How many attributes does it contain?
ncol(ecoregions)
# What is its geometry?
st_geometry_type(ecoregions)

library(raster)
elevation = raster("data/elevation.tif")
elevation
# What can you say about the contents of this file? 
# What type of data does it store? Raster data of RasterLayer class
class(elevation)
# What is the coordinate system used?
crs(elevation) #or
projection(elevation)
# How many attributes does it contain?
nlayers(elevation)
