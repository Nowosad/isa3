#' 1. Think about how R can help you.
#' Why do you want to learn how to use it for spatial data analysis?
#' 2. Have a look at [CRAN Task View: Analysis of Spatial Data](https://cran.r-project.org/web/views/Spatial.html) and check if there are any packages that may be useful in your daily work?
#' 3. Read the `ecoregions.gpkg` file, containing the borders of the World ecoregions (https://ecoregions2017.appspot.com/), into R.
#' Display this object and view its structure.
#' What can you say about the contents of this file? 
#' What type of data does it store? 
#' What is the coordinate system used?
#' How many attributes does it contain?
#' What is its geometry?
#' 4. Read the `elevation.tif` file, containing the digital elevation model for the World (https://globalmaps.github.io/el.html), into R.
#' Display this object and view its structure.
#' What can you say about the contents of this file? 
#' What type of data does it store? 
#' What is the coordinate system used?
#' How many attributes does it contain?
