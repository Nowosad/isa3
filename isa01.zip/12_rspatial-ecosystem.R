# citation()
citation("tmap")









library(spData)
library(sp)
library(sf)
world_sp = as(world, Class = "Spatial")
# sp functions ...

world_sf = st_as_sf(world_sp)

# lsf.str("package:sf")
ls("package:sf")



library(spData)
library(sf)

world

plot(world)

file_path = system.file("shapes/world.gpkg", package = "spData")
file_path
# world = read_sf(file_path)

world = read_sf("/home/jn/R/x86_64-redhat-linux-gnu-library/3.6/spData/shapes/world.gpkg")

cycle_hire_txt = system.file("misc/cycle_hire_xy.csv", package = "spData")
cycle_hire_xy = read_sf(cycle_hire_txt, options = c("X_POSSIBLE_NAMES=X",
                                                    "Y_POSSIBLE_NAMES=Y"))

my_point_sfg1 = st_point(c(1, 5))
my_point_sfg2 = st_point(c(3, 3))
my_point_sfc = st_sfc(my_point_sfg1, my_point_sfg2, crs = 4326)
my_df = data.frame(name = c("first", "second"))
my_point_sf = st_sf(my_df, geometry = my_point_sfc)

library(spData)
library(raster)

elev

plot(elev)

elev[]

raster_filepath = system.file("raster/srtm.tif", package = "spDataLarge")
new_raster = raster(raster_filepath)
new_raster

raster_filepath2 = system.file("raster/landsat.tif", package = "spDataLarge")
new_raster2 = raster(raster_filepath2)
plot(new_raster2)

new_raster3 = stack(raster_filepath2)
plot(new_raster3)

new_raster4 = brick(raster_filepath2)
plot(new_raster4)

my_raster = raster(nrows = 10, ncols = 20, 
                   xmn = 0, xmx = 20, ymn = -10, ymx = 0,
                   crs = "+init=epsg:4326",
                   vals = 1:200)
plot(my_raster)

my_raster2 = raster(res = c(1, 1),
                    xmn = 0, xmx = 20, ymn = -10, ymx = 0,
                    crs = "+init=epsg:4326",
                    vals = 1:200)
plot(my_raster2)
