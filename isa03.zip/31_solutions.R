library(dplyr)
library(spData)
library(sf)

world1 = dplyr::select(world, name_long, continent, pop)
world1

world2 = world[c("name_long", "continent", "pop")]
world2

ex2_a = world %>% 
  filter(continent == "Africa")

ex2_b = world %>% 
  filter(pop > 35000000)

ex2_c = world %>% 
  filter(continent == "Africa",
         pop > 35000000)

library(spDataLarge)
tm_shape(nz_elev) +
  tm_raster()

# raster - useful when we want to keep spatial information (e.g. projection, location)
ex3_1 = nz_elev[nz_elev > 2000, drop = FALSE]

# numeric vector
ex3_2 = nz_elev[nz_elev > 2000]
