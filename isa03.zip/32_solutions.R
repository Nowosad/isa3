#' 1. Create a new object, `world_pop_dens`, and add a new column `pop_dens` with a population density for each country.
#' 
## -------------------------------------------------------------------------
library(sf)
library(spData)
library(dplyr)
world_pop_dens = world %>% 
  mutate(pop_dens = pop/area_km2)
world_pop_dens

# world_pop_dens %>% 
#   arrange(-pop_dens) %>% 
#   slice(1:5) %>% 
#   dplyr::select(name_long, pop_dens)

#' 
#' 2. Calculate a maximum, minimum, and average elevation in the `nz_elev` dataset.
#' 
## -------------------------------------------------------------------------
library(spDataLarge)
nz_elev

cellStats(nz_elev, min)
cellStats(nz_elev, max)
cellStats(nz_elev, mean)

#' 
#' 3. Replace the values between 2000 and 3000 in the `nz_elev` dataset with a value of `NA`. 
#' Calculate a maximum, minimum, and average elevation in the newly created object.
#' 
## -------------------------------------------------------------------------
nz_elev2 = nz_elev
nz_elev2[nz_elev2 > 2000 & nz_elev2 < 3000] = NA
cellStats(nz_elev2, min)
cellStats(nz_elev2, max)
cellStats(nz_elev2, mean)

#' 
#' 4. Replace the values of 8 with a value of 1 in the `nlcd` dataset.
#' 
## -------------------------------------------------------------------------
plot(nlcd)

nlcd[nlcd == 8] = 1
plot(nlcd)

