library(sf)
library(spData)
library(dplyr)
world_pop_dens = world %>% 
  mutate(pop_dens = pop/area_km2)
world_pop_dens

# world_pop_dens %>% 
#   arrange(-pop_dens) %>% 
#   slice(1:5) %>% 
#   dplyr::select(name_long, pop_dens)

library(spDataLarge)
nz_elev

cellStats(nz_elev, min)
cellStats(nz_elev, max)
cellStats(nz_elev, mean)

nz_elev2 = nz_elev
nz_elev2[nz_elev2 > 2000 & nz_elev2 < 3000] = NA
cellStats(nz_elev2, min)
cellStats(nz_elev2, max)
cellStats(nz_elev2, mean)

plot(nlcd)

nlcd[nlcd == 8] = 1
plot(nlcd)
