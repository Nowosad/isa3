#' 1. Create a new object, `world_pop_dens`, and add a new column `pop_dens` with a population density for each country.
#' 2. Calculate a maximum, minimum, and average elevation in the `nz_elev` dataset.
#' 3. Replace the values between 2000 and 3000 in the `nz_elev` dataset with a value of `NA`. 
#' Calculate a maximum, minimum, and average elevation in the newly created object.
#' 4. Replace the values of 8 with a value of 1 in the `nlcd` dataset.
