library(spData)
library(sf)
library(dplyr)

seine_df = data.frame(Discharge = c(75, 21, 66),
                      Type = c("T", "T", "M"))

seine_df
seine

seine2 = bind_cols(seine, seine_df)
seine2 = st_as_sf(seine2)

library(tmap)
tm_shape(seine2) + tm_lines("Discharge", palette = "Blues") +
  tm_layout(bg.color = "darkgray")

us_states
us_states_df

?join

anti_join(us_states, us_states_df, by = c("NAME" = "state"))
anti_join(us_states_df, us_states, by = c("state" = "NAME"))

setdiff(us_states$NAME, us_states_df$state)
setdiff(us_states_df$state, us_states$NAME)

us_states
us_states_df

us_states2 = left_join(us_states, us_states_df,
                       by = c("NAME" = "state"))
tm_shape(us_states2) + 
  tm_polygons(col = "poverty_level_15") +
  tm_layout(legend.outside = TRUE)

tm1 = tm_shape(us_states2) +
  tm_polygons("median_income_10",
              breaks = c(20000, 35000, 50000))
tm2 = tm_shape(us_states2) +
  tm_polygons("median_income_15",
              breaks = c(20000, 35000, 50000))
tmap_arrange(tm1, tm2, ncol = 1)

us_states2
library(tidyr)
us_states3 = gather(us_states2, 
                    key = "year", value = "mi",
                    median_income_10:median_income_15)
us_states3

tm_shape(us_states3) +
  tm_polygons("mi") +
  tm_facets("year")
