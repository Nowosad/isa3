## srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
## srtm2 = aggregate(srtm, fact = 4)
## zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))
## zion = st_transform(zion, projection(srtm2))
