#' 1. Select the elevation data for the Northland and Auckland regions only.
#' Vizualize the results.
#' 2. Run the code below first.
#' Calculate the distance to the park border from each location in the Zion National Park using the `srtm2` object.
#' (Hint: Visit the `?mask` function documentation.)
#' 
## ---- eval=FALSE----------------------------------------------------------
## srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
## srtm2 = aggregate(srtm, fact = 4)
## zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))
## zion = st_transform(zion, projection(srtm2))

