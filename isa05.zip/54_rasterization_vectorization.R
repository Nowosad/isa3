library(sf)
library(spData)
library(raster)
library(dplyr)
cycle_hire_osm_projected = st_transform(cycle_hire_osm, 27700)
raster_template = raster(extent(cycle_hire_osm_projected), 
                         resolution = 1000,
                         crs = st_crs(cycle_hire_osm_projected)$proj4string)

ch_raster1 = rasterize(cycle_hire_osm_projected, raster_template, field = 1)



ch_raster2 = rasterize(cycle_hire_osm_projected, raster_template, field = 1, fun = "count")



ch_raster3 = rasterize(cycle_hire_osm_projected, raster_template, field = "capacity", fun = sum)



world_moll = st_transform(world, crs = "+proj=moll")
raster_template2 = raster(extent(world_moll), 
                         resolution = 100000,
                         crs = st_crs(world_moll)$proj4string)

w_raster1 = rasterize(world_moll, raster_template2)



grain
grain_poly = rasterToPolygons(grain) %>% 
  st_as_sf()
grain_poly2 = grain_poly %>% 
  group_by(layer) %>%
  summarize()
