library(sf)
library(dplyr)
library(spData)

nz_sel = filter(nz, Name %in% c("Northland", "Auckland"))
plot(nz_sel)

nz_elev_sel = crop(nz_elev, nz_sel)
nz_elev_sel2 = mask(nz_elev_sel, nz_sel)

library(tmap)
tm_shape(nz_elev_sel2) + 
  tm_raster(style = "cont") +
  tm_shape(nz_sel) +
  tm_borders()

## srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
## srtm2 = aggregate(srtm, fact = 4)
## zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))
## zion = st_transform(zion, projection(srtm2))

srtm3 = mask(srtm2, zion, inverse = TRUE)
plot(srtm3)

srtm_dist = distance(srtm3)

library(tmap)
tm_shape(srtm_dist) + 
  tm_raster(style = "cont") +
  tm_shape(zion) +
  tm_borders()
