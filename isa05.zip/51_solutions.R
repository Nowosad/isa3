library(sf)
library(spData)

nz2 = st_union(nz)
nz_lines = st_cast(nz2, "MULTILINESTRING")
st_length(nz_lines)

nz_lines2 = st_simplify(nz_lines, dTolerance = 5000)
st_length(nz_lines2)

zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))

zion_b = st_buffer(zion, dist = 10000)
st_area(zion_b) - st_area(zion)

plot(zion_b)

zion2 = st_sym_difference(zion, zion_b)
plot(zion2)

ua2020 = filter(urban_agglomerations, year == 2020)

# approach 1
asia = filter(world, continent == "Asia")
ua2020_asia = st_intersection(ua2020, asia)

# approach 2
ua2020world = st_join(ua2020, world)
ua2020_asia2 = filter(ua2020world, continent == "Asia")

nz_study_area = st_as_sfc(st_bbox(c(xmin = 1400000, xmax = 1600000, ymin = 5000000, ymax = 5300000), crs = 2193))

tm_shape(nz) +
  tm_polygons() +
  tm_shape(nz_study_area) +
  tm_polygons(col = "red")

nza = st_intersection(nz, nz_study_area)
plot(nza)

france = filter(world, name_long == "France")
plot(france)

france_p = st_cast(france, "POLYGON")
m_france = france_p[2, ]

tm_shape(m_france) +
  tm_polygons()
