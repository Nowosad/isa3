#' 
#' 1. Extract elevation values in a 500 meters buffer around each point in `zion_points`.
#' Calculate the average value for each point. 
#' Extract elevation values for each point in `zion_points`.
#' Compare these two results.
#' 
## -------------------------------------------------------------------------
library(sf)
library(spData)
library(spDataLarge)
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm2 = projectRaster(srtm, crs = nlcd)

zion_points2 = st_transform(zion_points, crs = st_crs(srtm2))
zion_points_500 = st_buffer(zion_points2, 500)


multi_vals = extract(srtm2, zion_points_500)
multi_vals = lapply(multi_vals, mean)
multi_vals = do.call(c, multi_vals)

single_vals = extract(srtm2, zion_points2)

plot(multi_vals,single_vals)

#' 
#' 2. Extract elevation values for each region in `nz` from `nz_elev`. 
#' Which region has the lowest and largest average elevation value?
#' Which region has the lowest and largest diversity of elevation values?
#' 
## -------------------------------------------------------------------------
library(sf)
library(tmap)

tm_shape(nz_elev) +
  tm_raster(style = "cont") +
  tm_shape(nz) + 
  tm_borders(lwd = 3)

nz_extr = raster::extract(nz_elev, nz, df = TRUE)
head(nz_extr)
summary(nz_extr)

nz_extr_df = nz_extr %>% 
  group_by(ID) %>% 
  summarize(avg = mean(elevation, na.rm = TRUE))

nz = bind_cols(nz, nz_extr_df)
nz %>% 
  arrange(avg) %>% 
  slice(1) %>% 
  pull(Name)

nz %>% 
  arrange(-avg) %>% 
  slice(1) %>% 
  pull(Name)

