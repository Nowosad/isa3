library(sf)
library(raster)
library(spData)

australia = world %>% 
  filter(name_long == "Australia")

plot(st_geometry(australia))

australia8059 = st_transform(australia, 8059)

plot(st_geometry(australia8059))

raster_template = raster(extent(australia8059), 
                         resolution = 10000,
                         crs = st_crs(australia8059)$proj4string)

australia_r1 = rasterize(australia8059, raster_template)
plot(australia_r1)

australia_r2 = rasterize(australia8059, raster_template, getCover = TRUE)
plot(australia_r2)

nz_elev

raster_template_nz = raster(extent(nz_elev), 
                         resolution = 8000,
                         crs = nz_elev)

nz_elev2 = resample(nz_elev, raster_template_nz)

rcl = matrix(c(-9999, 300, 1,
               300, 1000, 2,
               1000, 9999, 3),
             ncol = 3, byrow = TRUE)

nz_elev3 = reclassify(nz_elev2, rcl)
plot(nz_elev3)

nz_elev_poly = rasterToPolygons(nz_elev3) %>% 
  st_as_sf()

plot(nz_elev_poly)
