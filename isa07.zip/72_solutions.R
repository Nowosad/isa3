library(sf)
library(rnaturalearth)
library(tmap)
uk3 = ne_countries(scale = 10, 
                   country = "United Kingdom",
                   type = "map_units",
                   returnclass = "sf") 
scotland2 = uk3 %>% 
  dplyr::filter(subunit == "Scotland")

tm_shape(uk3) +
  tm_borders() +
  tm_shape(scotland2, is.master = TRUE) +
  tm_polygons()

library(osmdata)
course_location = st_sfc(st_point(c(-4.268, 55.854)), crs = 4326)
course_location2 = st_transform(course_location, 27700)
course_location3 = st_buffer(course_location2, 1000)
course_location4 = st_transform(course_location3, 4326)

roads = opq(bbox = course_location4) %>% 
  add_osm_feature(key = "highway") %>% 
  osmdata_sf()
roads

tm_shape(course_location4) +
  tm_polygons() +
  tm_shape(roads$osm_lines) +
  tm_lines()

library(spData)
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))

roads_zion = opq(bbox = st_bbox(srtm)) %>% 
  add_osm_feature(key = "highway", value = "motorway") %>% 
  osmdata_sf()
zion_main_road = st_as_sf(st_union(roads_zion$osm_lines))

transect = raster::extract(srtm, zion_main_road)
transect

library(raster)
nz_elev_alt = getData("alt", country = "NZL", mask = TRUE)
nz_elev_alt = merge(nz_elev_alt[[1]], nz_elev_alt[[2]])

plot(nz_elev_alt)

plot(nz_elev)
