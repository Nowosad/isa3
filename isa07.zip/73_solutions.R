srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))

library(raster)
library(sf)
library(spData)
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))

zion_points$srtm = extract(srtm, zion_points)

write_sf(zion_points, "zion_points_srtm.gpkg")
write_sf(zion_points, "zion_points_srtm.shp")

zion_points_coords = as.data.frame(st_coordinates(zion_points))
zion_points2 = st_drop_geometry(zion_points)
zion_points2 = dplyr::bind_cols(zion_points2, zion_points_coords) 
write.csv(zion_points2, "zion_points_srtm.csv")

zion_points3 = read.csv("zion_points_srtm.csv")
zion_points3 = st_as_sf(zion_points2, coords = c("X", "Y"))
zion_points3

library(spDataLarge)
nlcd2 = projectRaster(nlcd, srtm, method = "ngb")
zion_points3$nlcd = extract(nlcd2, zion_points3)

write_sf(zion_points3, "zion_points_srtm.gpkg")
write_sf(zion_points3, "zion_points_srtm.shp")

zion_points3 = dplyr::bind_cols(zion_points3, zion_points_coords) 
write.csv(zion_points3, "zion_points_srtm.csv")

writeRaster(srtm, "srtm1.tif", datatyle = "INT1U")
writeRaster(srtm, "srtm2.tif", datatyle = "FLT4S")
writeRaster(srtm, "srtm3.tif", options("COMPRESS=LZW"))

srtm1 = raster("srtm1.tif")
srtm2 = raster("srtm2.tif")
srtm3 = raster("srtm3.tif")
