library(sf)
library(dplyr)
download.file(url = "hhttps://irma.nps.gov/Datastore/DownloadFile/637623",
              destfile = "nps_boundary.zip",
              mode = "wb")
dir.create("data")
unzip(zipfile = "nps_boundary.zip", exdir = "data")
usa_parks = read_sf("data/nps_boundary.shp") %>% 
  filter(UNIT_TYPE == "National Park")
file.remove("nps_boundary.zip")

plot(st_geometry(usa_parks))

library(raster)
# https://www.worldclim.org/
download.file("http://biogeo.ucdavis.edu/data/worldclim/v2.1/base/wc2.1_10m_tavg.zip",
              destfile = "wc2.1_10m_tavg.zip",
              mode = "wb")

dir.create("data")
unzip(zipfile = "wc2.1_10m_tavg.zip", exdir = "data")
file.remove("wc2.1_10m_tavg.zip")

tavg_05 = raster("data/wc2.1_10m_tavg_05.tif")
plot(tavg_05)
