#' 
#' Run the code:
#' 
## -------------------------------------------------------------------------
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))

#' 
#' 1. Extract elevation values (`srtm`) for the points from the `zion_points` object.
#' Save the result: (1) in the GeoPackage format, (2) in the ESRI Shapefile format, (3) as a text file.
#' The text file should have three columns with (1) elevation value, (2) latitude, (3) longitude. 
#' 2. Read the text file back to R as an sf object.
#' 3. Extract land cover categories (`nlcd` ) for the points from this new object.
#' Overwrite the three previously created files with new ones with additional information.
#' 4. Write the `srtm` object as a GeoTIFF file using: (1) an "INT1U" data type, (2) an "FLT4S" data type, (3) an "LZW" compression.
#' Compare the size of the output files.
#' Read the new files into R and visualize them.
#' Can you see any differences between them?
