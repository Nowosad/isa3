srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
