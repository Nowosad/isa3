#' 
#' 1. Create a map of Scotland. 
#' Keep the England and Nothern Ireland borders on the map to provide a context.
#' 2. Run the code `course_location = st_sfc(st_point(c(-4.268, 55.854)), crs = 4326)`to create a point representing the location of this course.
#' Create a 1-kilometer buffer around this point and download a road network for this area. 
#' Visualize the results.
#' (Hint: The https://wiki.openstreetmap.org/wiki/Map_Features website could be useful here.)
#' 3. Get the primary road network data for the Zion National Park area.
#' Extract the elevation values along the road.
#' 4. Download the elevation data for New Zealand using `getData()` function. 
#' Compare the result with the `nz_elev` object. 
#' Are there any differences between these two objects?
#' 5. Search for some more R data packages?
#' Are there any data packages potentially useful to your daily work? 
#' Check if you can download the data using these packages?
