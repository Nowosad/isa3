library(sf)
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)
data(zion_points, package = "spDataLarge")





zion_points2a = st_transform(zion_points,
                             crs = 26912)

## zion_points2b = st_transform(zion_points,
##                              crs = "+proj=utm +zone=12 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs")

zion_points3 = st_transform(zion_points, st_crs(zion))
zion_points3





library(raster)
cat_raster = raster(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
projection(cat_raster)

unique(cat_raster)



wgs84 = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"
cat_raster_wgs84 = projectRaster(cat_raster, crs = wgs84, method = "ngb")





con_raster = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
projection(con_raster)

# hist(con_raster)



equalarea = "+proj=laea +lat_0=37.32 +lon_0=-113.04"
con_raster_ea = projectRaster(con_raster, crs = equalarea, method = "bilinear")
projection(con_raster_ea)





srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)





zion2 = st_transform(zion, projection(srtm))





vector_filepath = system.file("vector/zion.gpkg", package = "spDataLarge")
new_vector = read_sf(vector_filepath)
st_crs(new_vector) # get CRS
new_vector = st_set_crs(new_vector, 4326) # set CRS

raster_filepath = system.file("raster/srtm.tif", package = "spDataLarge")
new_raster = raster(raster_filepath)
projection(new_raster) # get CRS
projection(new_raster) = "+proj=utm +zone=12 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 
                            +units=m +no_defs" # set CRS
