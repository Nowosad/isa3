library(sf)
library(tmap)
library(spData)
tm1 = tm_shape(us_states) +
  tm_polygons() +
  tm_grid()

us_states2 = st_transform(us_states, 'PROJCS["USA_Contiguous_Albers_Equal_Area_Conic",GEOGCS["GCS_North_American_1983",DATUM["North_American_Datum_1983",SPHEROID["GRS_1980",6378137,298.257222101]],PRIMEM["Greenwich",0],UNIT["Degree",0.017453292519943295]],PROJECTION["Albers_Conic_Equal_Area"],PARAMETER["False_Easting",0],PARAMETER["False_Northing",0],PARAMETER["longitude_of_center",-96],PARAMETER["Standard_Parallel_1",29.5],PARAMETER["Standard_Parallel_2",45.5],PARAMETER["latitude_of_center",37.5],UNIT["Meter",1],AUTHORITY["EPSG","102003"]]')

tm2 = tm_shape(us_states2) +
  tm_polygons() +
  tm_grid()

tmap_arrange(tm1, tm2)

a1 = st_area(us_states)
a2 = st_area(us_states2)

us_states2$diff = units::set_units(abs(a1 - a2), km2)

units::set_units(sum(a1 - a2), km2)

us_states2 %>%
  arrange(-diff)

library(raster)
library(gdalUtils)
nlcd_path = raster(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
srtm_path = system.file("raster/srtm.tif", package = "spDataLarge")

gdalwarp(srcfile = srtm_path,
         dstfile = "data/new_srtm.tif",
         t_srs = projection(nlcd_path))

new_srtm = raster("data/new_srtm.tif")
plot(new_srtm)

library(dplyr)
canada_mexico = filter(world, name_long %in% c("Canada", "Mexico"))
canada_mexico2 = st_transform(canada_mexico, st_crs(us_states))

all = c(st_geometry(us_states), st_geometry(canada_mexico2))
plot(all)
