library(spDataLarge)
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)

library(sf)
library(raster)
crs(srtm)
st_crs(zion)

plot(srtm, axes = TRUE); plot(st_geometry(zion), add = TRUE)
# answer: different projections

tm_shape(srtm) + 
  tm_raster() +
  tm_shape(zion) +
  tm_borders()
# answer: tmap automatically reprojects data
