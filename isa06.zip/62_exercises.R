#' 
#' 1. Transform the `us_states` object into the USA Contiguous Albers Equal Area Conic CRS (https://spatialreference.org/ref/esri/usa-contiguous-albers-equal-area-conic/).
#' Create a visualization comparing this object before and after reprojecting.
#' 2. Calculate states' areas before and after reprojecting. 
#' What is the average difference between the calculated states' areas?
#' What is the total difference between the calculated areas?
#' 3. Additional: try to use the `gdalwarp` function from the **gdalUtils** package to reproject the `srtm.tif` file to the CRS of the `zion` object. 
#' (Note: a blog post at https://nowosad.github.io/post/lsm-bp1/ could be useful here.)
#' 4. Select `"Canada"`, and `"Mexico"` from the `world` object. 
#' Add the results to the `us_states` object and visualize the results.
