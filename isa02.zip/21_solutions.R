library(sf)
library(tmap)
library(spData)
library(dplyr)
us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))

tm_shape(us_states) +
  tm_polygons(col = "#821433",
              lwd = 3)

tm_shape(us_states) +
  tm_polygons(col = "median_income_15",
              style = "jenks",
              palette = rcartocolor::carto_pal(5, "Emrld"))

# https://geocompr.github.io/post/
tm_shape(us_states) + 
  tm_polygons(col = "REGION", 
              title = "Region: ")

tm_shape(us_states) +
  tm_polygons(col = "median_income_15",
              midpoint = mean(us_states$median_income_15),
              palette = "RdYlGn")
