#' 
#' Run the code below:
#' 
## ---- message=FALSE----------------------------------------------------------------------
library(sf)
library(tmap)
library(spData)
library(dplyr)
us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))

#' 
#' The `us_states` object contains and a few attributes of states within the contiguous United States.
#' 
#' 1. Create a simple map of the contiguous United States. 
#' Change the colors of the polygons, and the width of the borders.
#' 
## ----------------------------------------------------------------------------------------
tm_shape(us_states) +
  tm_polygons(col = "#821433",
              lwd = 3)

#' 
#' 
#' 
#' 2. Create a map of the median income in 2015 (`median_income_15`) in the contiguous United States. 
#' Try different color scales' styles (the `style` argument) and different color palettes. 
#' Which are the most appropriate in this case?
#' 
## ----------------------------------------------------------------------------------------
tm_shape(us_states) +
  tm_polygons(col = "median_income_15",
              style = "jenks",
              palette = rcartocolor::carto_pal(5, "Emrld"))

#' 
#' 3. Create a map of the contiguous United States' regions.
#' Try different color palettes.
#' Change the legend title to `Region:`.
#' 
## ----------------------------------------------------------------------------------------
# https://geocompr.github.io/post/
tm_shape(us_states) + 
  tm_polygons(col = "REGION", 
              title = "Region: ")

#' 
#' 4. Additional: create a map of the median income in 2015 (`median_income_15`) in the contiguous United States, that shows which states had the income above and below the mean.
#' 
## ----------------------------------------------------------------------------------------
tm_shape(us_states) +
  tm_polygons(col = "median_income_15",
              midpoint = mean(us_states$median_income_15),
              palette = "RdYlGn")

