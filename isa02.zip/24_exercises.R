#' 
#' 1. Change the tmap mode to `"view"` and recreate maps from the "Maps - additional elements" slides' exercises. 
#' What are the pros and cons of using static or interactive maps?
#' What are the map's elements that can exist in static maps, but are not rendered in the interactive maps?
#' 2. Create a simple map of the contiguous United States using the `"view"` mode.
#' Try different basemaps (http://leaflet-extras.github.io/leaflet-providers/preview/).
#' 3. Save the map from Exercise 2 as a `.png`, `.svg`, and `.html` file. 
#' When can different file formats be useful?
