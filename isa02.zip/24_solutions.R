library(spData)
library(tmap)
tmap_mode("view")

urb_2020 =  subset(urban_agglomerations, year == 2020)
tm_shape(world) +
  tm_polygons() +
  tm_shape(urb_2020) +
  tm_symbols("population_millions") +
  tm_layout(title = "Map title") +
  tm_graticules() +
  tm_scale_bar() +
  tm_compass() +
  tm_credits("Text annotation")

library(spData)
library(tmap)
tmap_mode("view")

tm_shape(us_states) +
  tm_borders()

tm_shape(us_states) +
  tm_borders() +
  tm_basemap("OpenTopoMap")

## tm3 = tm_shape(us_states) +
##   tm_borders() +
##   tm_basemap("OpenTopoMap")
## 
## tmap_save(tm3, "tm3.png")
## tmap_save(tm3, "tm3.svg")
## tmap_save(tm3, "tm3.html")
