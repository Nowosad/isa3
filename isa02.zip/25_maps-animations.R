library(sf)
library(tmap)
library(spData)
urb_1970_2030 = subset(urban_agglomerations, year %in% c(1970, 1990, 2010, 2030))

tm_shape(world) +
  tm_polygons() +
  tm_shape(urb_1970_2030) +
  tm_symbols(col = "black", 
             border.col = "white",
             size = "population_millions") +
  tm_facets(by = "year", nrow = 1, free.coords = FALSE)

urban_agglomerations
unique(urban_agglomerations$year)

urb_anim = tm_shape(world) +
  tm_polygons() +
  tm_shape(urban_agglomerations) +
  tm_symbols(col = "black", 
             border.col = "white",
             size = "population_millions") +
  tm_facets(along = "year",
            free.coords = FALSE)

tmap_animation(urb_anim,
               filename = "urb_anim.gif",
               delay = 25,
               width = 7,
               height = 4)
