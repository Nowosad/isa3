library(sf)
library(tmap)
library(spData)
library(dplyr)
us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))

tm_shape(us_states) +
  tm_polygons() +
  tm_text("NAME", size = "AREA")

tm_shape(seine) +
  tm_lines()

tm_shape(seine) +
  tm_lines() +
  tm_layout(bg.color = "darkgray")

tm_shape(seine) +
  tm_lines(col = "blue") +
  tm_layout(bg.color = "darkgray")

urb_2020 =  subset(urban_agglomerations, year == 2020)
tm_shape(world) +
  tm_polygons() +
  tm_shape(urb_2020) +
  tm_symbols("population_millions") +
  tm_layout(title = "Map title") +
  tm_graticules() +
  tm_scale_bar() +
  tm_compass() +
  tm_credits("Text annotation")

tm_shape(world) +
  tm_polygons() +
  tm_shape(urb_2020) +
  tm_symbols("population_millions") +
  tm_layout(title = "Map title") +
  tm_graticules() +
  tm_scale_bar() +
  tm_compass() +
  tm_credits("Text annotation") +
  tm_style("classic")
