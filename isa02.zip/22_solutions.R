library(tmap)
library(sf)

data("rivers", package = "tmap")
tm_shape(rivers) +
  tm_lines("strokelwd")

library(spData)
urb_2020 =  subset(urban_agglomerations, year == 2020)
tm_shape(urb_2020) + tm_symbols()
tm_shape(urb_2020) + tm_squares()
tm_shape(urb_2020) + tm_bubbles()
tm_shape(urb_2020) + tm_dots()
tm_shape(urb_2020) + tm_markers()

tm_shape(world) +
  tm_polygons() +
  tm_shape(urb_2020) +
  tm_symbols("population_millions")

library(spDataLarge)
tm_shape(nz_elev) +
  tm_raster(breaks = c(-99, 0, 300, 600, 9999),
            labels = c("Depressions", "Plains", "Hills", "Mountains"),
            palette = "-RdYlGn",
            midpoint = 0)
