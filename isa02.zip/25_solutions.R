library(spData)
library(tmap)
tm_shape(world) +
  tm_polygons("lifeExp") +
  tm_facets("subregion")

urb_anim2 = tm_shape(world, projection = "+proj=moll") +
  tm_polygons() +
  tm_shape(urban_agglomerations) +
  tm_symbols(col = "black", 
             border.col = "white",
             size = "population_millions",
             title.size = "Population (millions)") +
  tm_facets(along = "year",
            free.coords = FALSE) +
  tm_layout(title = "Major urban areas worldwide")

## tmap_animation(urb_anim2,
##                filename = "urb_anim2.gif",
##                delay = 25,
##                width = 7,
##                height = 4)
