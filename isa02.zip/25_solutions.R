#' 
#' 1. Create a map of life expectancy using `world` with facets representing different subregions.
#' 
## ----------------------------------------------------------------------------------------
library(spData)
library(tmap)
tm_shape(world) +
  tm_polygons("lifeExp") +
  tm_facets("subregion")

#' 
#' 2. Think of how you can improve the map style of the `urb_anim` object.
#' Try to implement your ideas.
#' Save the results as a new file.
#' 
## ----------------------------------------------------------------------------------------
urb_anim2 = tm_shape(world, projection = "+proj=moll") +
  tm_polygons() +
  tm_shape(urban_agglomerations) +
  tm_symbols(col = "black", 
             border.col = "white",
             size = "population_millions",
             title.size = "Population (millions)") +
  tm_facets(along = "year",
            free.coords = FALSE) +
  tm_layout(title = "Major urban areas worldwide")

#' 
## ---- eval=FALSE-------------------------------------------------------------------------
## tmap_animation(urb_anim2,
##                filename = "urb_anim2.gif",
##                delay = 25,
##                width = 7,
##                height = 4)

#' 
