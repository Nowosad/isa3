#' 1. Load the `rivers` dataset from the **tmap** package using `data("rivers", package = "tmap")`.
#' Calculate lengths in kilometers of rivers stored in this object.
#' (Hint: you need to aggregate the data.)
#' 
## ----------------------------------------------------------------------------------------
library(tmap)
library(sf)
data("rivers", package = "tmap")
rivers %>% 
  group_by(name) %>% 
  summarise() %>% 
  mutate(len = st_length(.))

#' 
#' 2. Calculate the area of each region in the `nz` object. 
#' Compare it with the `Land_area` variable.
#' For which region the values are the most and the least different?
#' 
## ----------------------------------------------------------------------------------------
library(spData)
nz %>% 
  mutate(area = as.numeric(st_area(.)) / 1000000) %>% 
  mutate(area_diff = area - Land_area)

#' 
#' 3. What is the surface area of the areas above 2500 meters a.s.l. in the `srtm` dataset (`srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))`)?
#' 
## ----------------------------------------------------------------------------------------
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm2 = projectRaster(srtm, crs = nlcd)
(length(srtm2[srtm2 > 2500]) * xres(srtm2) * yres(srtm2)) / 1000000

