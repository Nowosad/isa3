library(tmap)
library(sf)
data("rivers", package = "tmap")
rivers %>% 
  group_by(name) %>% 
  summarise() %>% 
  mutate(len = st_length(.))

library(spData)
nz %>% 
  mutate(area = as.numeric(st_area(.)) / 1000000) %>% 
  mutate(area_diff = area - Land_area)

srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm2 = projectRaster(srtm, crs = nlcd)
(length(srtm2[srtm2 > 2500]) * xres(srtm2) * yres(srtm2)) / 1000000
