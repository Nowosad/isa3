library(spDataLarge)
library(tmap)
library(raster)

nz_now = tm_shape(nz_elev) +
  tm_raster(style = "cont",
            palette = "-RdYlGn",
            midpoint = 0) +
  tm_layout(bg.color = "lightblue")

nz_elev2 = nz_elev - 10
nz_elev2[nz_elev2 < 0] = NA

nz_plus10 = tm_shape(nz_elev2) +
  tm_raster(style = "cont",
            palette = "-RdYlGn",
            midpoint = 0) +
  tm_layout(bg.color = "lightblue")

nz_elev3 = nz_elev - 100
nz_elev3[nz_elev3 < 0] = NA

nz_plus100 = tm_shape(nz_elev3) +
  tm_raster(style = "cont",
            palette = "-RdYlGn",
            midpoint = 0) +
  tm_layout(bg.color = "lightblue")

tmap_arrange(nz_now, nz_plus10, nz_plus100)

# areas
cell_diff_plus10 = sum(is.na(nz_elev2[])) - sum(is.na(nz_elev[]))

(cell_diff_plus10 * xres(nz_elev) * yres(nz_elev)) / 1000000 # change in km2

cell_diff_plus100 = sum(is.na(nz_elev3[])) - sum(is.na(nz_elev[]))

(cell_diff_plus100 * xres(nz_elev) * yres(nz_elev)) / 1000000 # change in km2

library(spDataLarge)
nlcd
rcl = matrix(c(1, 1, 8, 1, 2, 2, 3, 3, 4, 4, 5, 4, 6, 4, 7, 4),
             ncol = 2, byrow = TRUE)
nlcd_recl = reclassify(nlcd, rcl = rcl)

landsat_path = system.file("raster/landsat.tif", package = "spDataLarge")
landsat = stack(landsat_path)

savi_fun = function(nir, red, L = 0.5){
  ((1 + L) * (nir - red)) / (nir + red + L)
}
savi = overlay(landsat[[4]], landsat[[3]], fun = savi_fun)
plot(savi)

library(RStoolbox)
savi2 = spectralIndices(landsat, red = 3, nir = 4, indices = "SAVI")

savi_diff = savi - savi2
savi_diff

savi_focal3 = focal(savi, 
                    w = matrix(1, nrow = 3, ncol = 3), 
                    fun = mean)

savi_focal10 = focal(savi, 
                     w = matrix(1, nrow = 9, ncol = 9), 
                     fun = mean)

tm_shape(stack(savi, savi_focal3, savi_focal10)) +
  tm_raster(style = "cont")

srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm2 = projectRaster(srtm, nlcd)
zonal(srtm2, nlcd, fun = "min")
zonal(srtm2, nlcd, fun = "mean")
zonal(srtm2, nlcd, fun = "max")

rcl2 = zonal(srtm2, nlcd, fun = "mean")
nlcd_recl = reclassify(nlcd, rcl = rcl2)

getData("ISO3") %>% 
  filter(NAME %in% c("United Kingdom",
                     "Ireland",
                     "Isle of Man")) %>% 
  pull(ISO3)

irl = getData("alt", country = "IRL", mask = TRUE)
imn = getData("alt", country = "IMN", mask = TRUE)
gbr = getData("alt", country = "GBR", mask = TRUE)

british_isles = merge(irl, gbr)
plot(british_isles)
