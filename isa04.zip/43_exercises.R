#' 1. Calculate an average population density on the world and the continent level.
#' How can it be done? 
#' 2. Create a map with three panels representing a population density on a (1) country, (2) continent, and (3) world level.
#' 3. Create a map of New Zealand's regions with New Zealand borders represented by a thick line.
#' How can this be achieved?
#' 4. Create a new variable `pop_change` in the `us_states` dataset. 
#' This variable should represent changes between the population in 2010 and 2015.
#' Aggregate the US states into two groups: (1) with population growth, (2) with a population loss.
#' Visualize the results.
#' 5. The `nz_elev` dataset has a resolution of 1000 meters. 
#' Change it to a resolution of 10 kilometers. 
#' Create two maps comparing the results.
#' When the map with a lower resolution could we useful?
