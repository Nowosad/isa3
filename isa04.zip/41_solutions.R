library(spData)
library(sf)

nz_new = nz[nz_height, ]
plot(nz_new)

library(tmap)
tm_shape(nz) +
  tm_polygons(col = "grey50") +
  tm_shape(nz_new) + 
  tm_polygons(col = "blue") +
  tm_shape(nz_height) +
  tm_dots(size = 2)

waikato = filter(nz, Name == "Waikato")
st_touches(waikato, nz)

ans2 = nz %>% 
  filter(st_touches(., waikato, sparse = FALSE))

tm_shape(nz) +
  tm_polygons() +
  tm_shape(waikato) +
  tm_polygons("red") +
  tm_shape(ans2) +
  tm_polygons("green")

canterbury = filter(nz, Name == "Canterbury")
sel1 = st_is_within_distance(canterbury, nz_height,
                             dist = 1000, sparse = FALSE)
sum(sel1)
sel2 = st_intersects(canterbury, nz_height, sparse = FALSE)
sum(sel2)

sum(sel1) - sum(sel2)

urban_agglomerations
world

tm_shape(world) +
  tm_polygons() + 
  tm_shape(urban_agglomerations) +
  tm_dots(size = 0.25)

sel_world = st_join(world, urban_agglomerations) %>%
  filter(is.na(urban_agglomeration))

tm_shape(world) +
  tm_polygons() + 
  tm_shape(sel_world) +
  tm_polygons("red") +
  tm_shape(urban_agglomerations) +
  tm_dots(size = 0.25) 

library(spData)
data("rivers", package = "tmap")

tm_shape(world) +
  tm_polygons(alpha = 0.1) +
  tm_shape(rivers) + 
  tm_lines(col = "darkblue")

rivers2 = rivers %>% 
  group_by(name) %>% 
  summarize()

world_rivers = st_join(world, rivers2, left = FALSE)
colnames(world)

library(dplyr)
world_rivers %>% 
  group_by(name_long) %>% 
  summarise(number_of_rivers = n()) %>% 
  arrange(-number_of_rivers)
