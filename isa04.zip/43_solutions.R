library(sf)
library(spData)
library(dplyr)
world_pop_dens = world %>% 
  mutate(pop_dens = pop/area_km2)

world_pop_dens_g = world_pop_dens %>% 
  summarise(dens_avg = mean(pop_dens, na.rm = TRUE))

world_pop_dens_c = world_pop_dens %>% 
  group_by(continent) %>% 
  summarize(dens_avg = mean(pop_dens, na.rm = TRUE))

tm1 = tm_shape(world_pop_dens) + tm_polygons("pop_dens")
tm2 = tm_shape(world_pop_dens_c) + tm_polygons("dens_avg")
tm3 = tm_shape(world_pop_dens_g) + tm_polygons("dens_avg")

tmap_arrange(tm1, tm2, tm3)

library(spData)
library(dplyr)
nz_agg = nz %>% 
  summarize()

library(tmap)
tm_shape(nz) +
  tm_polygons() +
  tm_shape(nz_agg) +
  tm_borders(lwd = 4, col = "red")

us_states2 = us_states %>% 
  mutate(pop_change = total_pop_15 - total_pop_10) %>% 
  mutate(pop_change2 = pop_change > 0) %>% 
  group_by(pop_change2) %>% 
  summarize()

tm_shape(us_states2) +
  tm_polygons(col = "pop_change2", lwd = 7) +
  tm_shape(us_states) +
  tm_borders()

nz_elev2 = aggregate(nz_elev, fact = 10)

my_breaks = c(0, 1000, 2000, 3000, 4000, 5000)

tm1 = tm_shape(nz_elev) + tm_raster(breaks = my_breaks)
tm2 = tm_shape(nz_elev2) + tm_raster(breaks = my_breaks)
tmap_arrange(tm1, tm2)
